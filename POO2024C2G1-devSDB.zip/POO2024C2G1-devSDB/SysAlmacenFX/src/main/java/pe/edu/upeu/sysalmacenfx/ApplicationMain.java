package pe.edu.upeu.sysalmacenfx;

public class ApplicationMain {
    public static void main(String[] args) {
        SysAlmacenFxApplication.main(args);
    }
}
