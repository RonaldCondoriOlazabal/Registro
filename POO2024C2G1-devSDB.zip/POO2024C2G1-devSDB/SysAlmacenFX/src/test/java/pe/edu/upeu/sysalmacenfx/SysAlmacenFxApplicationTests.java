package pe.edu.upeu.sysalmacenfx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysAlmacenFxApplicationTests {

	@Test
	void contextLoads() {
	}

}
